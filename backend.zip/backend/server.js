const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

app.post("/chat", async (req, res) => {
  try {
    const { message, stats } = req.body;

    // 1. Prepare the Financial Context
    // This allows the AI to "see" your budget without you typing it
    const financialContext = stats ? `
      [USER FINANCIAL STATUS]
      Current Balance: ₹${stats.balance}
      Monthly Income: ₹${stats.income}
      Spent this Month: ₹${stats.spentThisMonth}
      Recent Transactions: ${stats.recentExpenses?.join(", ") || "None yet"}
    ` : "[No budget data shared]";

    // 2. Format Chat History
    let userText = "";
    if (Array.isArray(message)) {
      userText = message.map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join("\n");
    } else {
      userText = message;
    }

    // 3. API Configuration (Using April 2026 Stable Model)
    const MODEL = "gemini-3-flash-preview"; 
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${process.env.API_KEY}`;

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: `You are BrokeBuddy AI, a witty financial coach for Indian students.
            
            ${financialContext}

            INSTRUCTIONS:
            - Use the budget data above to give specific advice (e.g., "You only have ₹500 left").
            - Be concise but thorough (2-3 paragraphs).
            - Always use ₹ (INR) symbols.
            - If they can't afford something, suggest a cheaper "Student Hack."
            - Never give generic advice; make it about THEIR numbers.

            CONVERSATION:
            ${userText}`
          }]
        }],
        generationConfig: {
          temperature: 0.75,
          maxOutputTokens: 800,
          topP: 0.95
        }
      })
    });

    const data = await response.json();

    // 4. Handle API Errors (Quota, Key, or Model issues)
    if (data.error) {
      console.error("API ERROR:", data.error.message);
      return res.status(data.error.code || 500).json({ 
        reply: "⚠️ My financial brain is foggy. Check your API key or daily limits!" 
      });
    }

    // 5. Send Response
    const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || "I'm drawing a blank on that one, buddy.";
    res.json({ reply });

  } catch (err) {
    console.error("SERVER ERROR:", err);
    res.status(500).json({ reply: "⚡ Server Error: Check your terminal." });
  }
});

// Deployment-friendly Port
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 BrokeBuddy Backend active on port ${PORT}`);
  console.log(`📡 Using Model: gemini-3-flash-preview`);
});